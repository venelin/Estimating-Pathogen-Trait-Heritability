require(benchtable)
source('lmFit.R')
doBenchJob(fname="lmFit")

