---
title: "NEWS about the toyepidemic R-package"
author: "Venelin Mitov"
date: "05 January, 2018"
output: html_document
---

# toyepidemic 0.1.0
* First version of the package on github.

